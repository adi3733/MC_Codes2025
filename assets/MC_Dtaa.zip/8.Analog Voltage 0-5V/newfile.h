/* 
 * File:   newfile.h
 * Author: adity
 *
 * Created on 14 October, 2025, 3:30 PM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

