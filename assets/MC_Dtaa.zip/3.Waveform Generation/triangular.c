#include <reg51.h>

void delay(unsigned int);

void main(void)
{
    unsigned int x;
    
    while(1)
    {
        for(x = 0; x < 250; x++)
        {
            P1 = x;
            delay(100);
        }
        for(x = 250; x > 0; x--)
        {
            P1 = x;
            delay(100);
        }
    }
}

void delay(unsigned int time)
{
    unsigned int i, j;
    for(i=0; i<time; i++)
        for(j=0; j<1275; j++);
}
