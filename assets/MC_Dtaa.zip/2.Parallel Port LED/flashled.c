#include <REGX51.H>

void delay(unsigned int time) {
    unsigned int i, j;
    for(i = 0; i < time; i++)
        for(j = 0; j < 1275; j++);
}

void main() {
    while(1) {
        P1 = 0x00;   // Turn ON all LEDs (active low)
        delay(500);
        P1 = 0xFF;   // Turn OFF all LEDs
        delay(500);
    }
}
