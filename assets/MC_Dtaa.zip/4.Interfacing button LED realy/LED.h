/* 
 * File:   LED.h
 * Author: adity
 *
 * Created on 14 October, 2025, 11:22 AM
 */

#ifndef LED_H
#define	LED_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* LED_H */

