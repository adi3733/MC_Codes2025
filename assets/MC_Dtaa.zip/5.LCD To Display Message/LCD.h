/* 
 * File:   LCD.h
 * Author: adity
 *
 * Created on 14 October, 2025, 12:13 PM
 */

#ifndef LCD_H
#define	LCD_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* LCD_H */

